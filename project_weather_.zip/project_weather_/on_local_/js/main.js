data_csv = 'latitude,longitude,city,country\x0a' + '52.367,4.904,Amsterdam,Netherlands\x0a' + '39.933,32.859,Ankara,Turkey\x0a' + '56.134,12.945,Åstorp,Sweden\x0a' + '37.983,23.727,Athens,Greece\x0a' + '54.597,-5.930,Belfast,Northern\x20Ireland\x0a' + '41.387,2.168,Barcelona,Spain\x0a' + '52.520,13.405,Berlin,Germany\x0a' + '46.948,7.447,Bern,Switzerland\x0a' + '43.263,-2.935,Bilbao,Spain\x0a' + '50.847,4.357,Brussels,Belgium\x0a' + '47.497,19.040,Bucharest,Romania\x0a' + '59.329,18.068,Budapest,Hungary\x0a' + '51.483,-3.168,Cardiff,Wales\x0a' + '50.937,6.96,Cologne,Germany\x0a' + '55.676,12.568,Copenhagen,Denmark\x0a' + '51.898,-8.475,Cork,Ireland\x0a' + '53.349,-6.260,Dublin,Ireland\x0a' + '55.953,-3.188,Edinburgh,Scotland\x0a' + '43.7696,11.255,Florence,Italy\x0a' + '50.110,8.682,Frankfurt,Germany\x20\x20\x20\x20\x20\x20\x20\x20\x0a' + '43.254,6.637,French\x20Riviera,France\x0a' + '32.650,-16.908,Funchal,Portugual\x0a' + '36.140,-5.353,Gibraltar\x0a' + '57.708,11.974,Gothenburg,Sweden\x20\x20\x20\x20\x20\x0a' + '53.548,9.987,Hamburg,Germany\x0a' + '60.169,24.938,Helsinki,Finland\x0a' + '39.020,1.482,Ibiza,Spain\x0a' + '50.450,30.523,Kyiv,Ukraine\x0a' + '61.115,10.466,Lillehammer,Norway\x0a' + '38.722,-9.139,Lisbon,Portugual\x0a' + '51.507,-0.127,London,England\x20\x20\x20\x20\x20\x20\x0a' + '40.416,-3.703,Madrid,Spain\x0a' + '39.695,3.017,Mallorca,Spain\x0a' + '53.480,-2.242,Manchester,England\x20\x20\x20\x20\x20\x20\x20\x0a' + '43.296,5.369,Marseille,France\x0a' + '27.760,-15.586,Maspalomas,Spain\x0a' + '45.464,9.190,Milan,Italy\x0a' + '48.135,11.582,Munich,Germany\x0a' + '40.851,14.268,Naples,Italy\x0a' + '43.034,-2.417,Oñati,Spain\x0a' + '59.913,10.752,Oslo,Norway\x0a' + '48.856,2.352,Paris,France\x0a' + '50.075,14.437,Prague,Czech\x20Republic\x0a' + '64.146,-21.942,Reykjavík,Iceland\x0a' + '56.879,24.603,Riga,Latvia\x0a' + '41.902,12.496,Rome,Italy\x0a' + '39.453,-31.127,Santa\x20Cruz\x20das\x20Flores,Portugual\x0a' + '28.463,-16.251,Santa\x20Cruz\x20de\x20Tenerife,Spain\x0a' + '57.273,-6.215,Skye,Scotland\x0a' + '42.697,23.321,Sofia,Bulgaria\x0a' + '59.329,18.068,Stockholm,Sweden\x0a' + '59.437,24.753,Tallinn,Estonia\x0a' + '18.208,16.373,Vienna,Austria\x0a' + '52.229,21.012,Warsaw,Poland\x0a' + '53.961,-1.07,York,England\x0a' + '47.376,8.541,Zurich,Switzerland';
function add_option(a, b) {
    var c = document['getElementById']('list_of__lang__'), d = document['createElement']('option');
    d['text'] = a, d['value'] = b, c['appendChild'](d);
}
function getData() {
    const a = data_csv['split'](/\n/)['slice'](0x1);
    a['forEach'](b => {
        const c = b['split'](','), d = c[0x0], e = c[0x1];
    });
    for (i = 0x0; i < a['length']; i++) {
        label = a[i]['split'](',')[0x2], a[i]['split'](',')[0x3], latlag = a[i]['split'](',')[0x0] + '|' + a[i]['split'](',')[0x1], add_option(label, latlag);
    }
}
function sleep(a) {
    return new Promise(b => setTimeout(b, a));
}
async function animation_play(a) {
    animation_ = document['getElementsByClassName']('loader')[0x0], i = 0x0;
    do {
        i += 0x1, animation_['style']['animation'] = 'spin\x205s\x20linear\x20infinite', animation_['style']['display'] = 'block', console['log']('I\x20must\x20be\x20there'), await sleep(0x7d0);
    } while (i > 0x1);
    {
        if (a != !![])
            animation_['style']['animationPlayState'] = 'paused';
        animation_['style']['display'] = 'none', console['log']('I\x27m\x20gone');
    }
}
document['getElementsByClassName']('loader')[0x0]['style']['display'] = '', getData();
function get_coordinates(a) {
    animation_play(!![]), latlag = a['options'][a['selectedIndex']]['value'], latlag = [
        latlag['split']('|')[0x0],
        latlag['split']('|')[0x1]
    ], console['log'](latlag), document['querySelectorAll']('.scroll-container\x20*')['forEach'](b => b['remove']()), get_json(latlag), animation_play();
}
function get_day(a) {
    a = String(a), weekday = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
    ];
    const b = [
        a['slice'](0x0, 0x4),
        a['slice'](0x4, 0x6),
        a['slice'](0x6, 0x8)
    ];
    globalThis['date_'] = b['join']('-');
    const c = new Date(date_);
    let e = weekday[c['getDay']()];
    return console['log'](e), e['toUpperCase']();
}
var dictionary_ = {
    'clear': [
        'clear',
        'Total\x20cloud\x20cover\x20less\x20than\x2020%'
    ],
    'pcloudy': [
        'partly\x20cloudy',
        'Total\x20cloud\x20cover\x20between\x2020%-60%'
    ],
    'mcloudy': [
        'mainly\x20cloudy',
        'Total\x20cloud\x20cover\x20between\x2060%-80%'
    ],
    'cloudy': [
        'cloudy',
        'Total\x20cloud\x20cover\x20over\x20over\x2080%'
    ],
    'humid': [
        'humid',
        'Relative\x20humidity\x20over\x2090%\x20with\x20total\x20cloud\x20cover\x20less\x20than\x2060%'
    ],
    'lightrain': [
        'light\x20rain',
        'Precipitation\x20rate\x20less\x20than\x204mm/hr\x20with\x20total\x20cloud\x20cover\x20more\x20than\x2080%'
    ],
    'oshower': [
        'occasional\x20shower',
        'Precipitation\x20rate\x20less\x20than\x204mm/hr\x20with\x20total\x20cloud\x20cover\x20between\x2060%-80%'
    ],
    'ishower': [
        'isolated\x20shower',
        'Precipitation\x20rate\x20less\x20than\x204mm/hr\x20with\x20total\x20cloud\x20cover\x20less\x20than\x2060%'
    ],
    'lightsnow': [
        'light\x20snow',
        'Precipitation\x20rate\x20less\x20than\x204mm/hr'
    ],
    'rain': [
        'rain',
        'Precipitation\x20rate\x20over\x204mm/hr'
    ],
    'snow': [
        'snow',
        'Precipitation\x20rate\x20over\x204mm/hr'
    ],
    'rainsnow': [
        'rain\x20snow',
        'Precipitation\x20type\x20to\x20be\x20ice\x20pellets'
    ],
    'ts': [
        'Thunderstorm\x20possible',
        '\x20Lifted\x20Index\x20less\x20than\x20-5\x20with\x20precipitation\x20rate\x20below\x204mm/hr'
    ],
    'tsrain': [
        'Thunderstorm\x20rain',
        '\x20Lifted\x20Index\x20less\x20than\x20-5\x20with\x20precipitation\x20rate\x20over\x204mm/hr'
    ],
    'Undefined': [
        '-9999',
        'Undefined'
    ]
};
function get_json(a) {
    (function () {
        var b = 'http://www.7timer.info/bin/api.pl?';
        $['getJSON'](b, {
            'lon': a[0x0],
            'lat': a[0x1],
            'product': 'civillight',
            'output': 'json'
        })['done'](function (c) {
            console['log'](a[0x0], '>>>>>>>>>>>>>>>>>>>>>>>>>', a[0x1]), $['each'](c['dataseries'], function (d, e) {
                if (String(e['weather']) == 'ts')
                    img = 'http://www.7timer.info/img/misc/about_civil_tstorm.png';
                else
                    img = 'http://www.7timer.info/img/misc/about_civil_' + e['weather'] + '.png';
                content = '<div\x20class=\x27card\x27>' + '<p\x20style=\x27text-align:\x20center\x27;>\x20<h3\x20style=\x27color:rgb(6,139,95);\x27>' + get_day(e['date']) + '</h3>\x20\x20</p>' + '<img\x20src=' + img + '\x20</img>' + '<div>' + '<h4>' + dictionary_[String(e['weather'])][0x0]['toUpperCase']() + '</h4>' + '<p>' + dictionary_[String(e['weather'])][0x1] + '</p>' + '<p\x20sytle=\x27margin-bottom:-2;\x27><h4>\x20H:' + String(e['temp2m']['max']) + '</h4></p>' + '<p\x20sytle=\x27margin-bottom:-2;\x27><h4>\x20L:' + String(e['temp2m']['min']) + '</h4></p>' + '<p\x20sytle=\x27margin-bottom:-2;\x27><small>\x20' + date_ + '</small></p>' + '</div>' + '</div>', $(content)['appendTo']('#scroll-container');
            });
        });
    }());
}